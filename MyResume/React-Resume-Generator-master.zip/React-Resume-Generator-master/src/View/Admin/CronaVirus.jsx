import React, { Component } from "react";

class CronaVirus extends Component {
  constructor(props) {
    super(props);
    this.state = {
      virus: []
    };
  }

  render() {
    return (
      <div>
        <h1>Hello CronaVirus</h1>
      </div>
    );
  }
}

export default CronaVirus;
