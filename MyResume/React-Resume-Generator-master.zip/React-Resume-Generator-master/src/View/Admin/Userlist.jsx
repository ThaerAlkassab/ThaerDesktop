import React, { Component } from "react";

class Userlist extends Component {
  render() {
    return (
      <div>
        <h1>Hey Resume List</h1>
      </div>
    );
  }
}

export default Userlist;
