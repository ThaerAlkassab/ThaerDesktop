import React, { Component } from "react";

export class Details extends Component {
  render() {
    return (
      <div>
        <h1>Resume Detail List</h1>
      </div>
    );
  }
}

export default Details;
